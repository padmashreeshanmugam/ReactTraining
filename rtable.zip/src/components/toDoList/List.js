// import React from 'react';


// class List  extends React.Component{
//     state ={
//         inputValue: "",
//         rows :[]
//     }
//     handleClick () {
//         var rows =this.state.rows;
//         rows.push(this.state.inputValue);
//         this.setState({
//             rows :rows
//         })
//     }
//     handlechange(){
//        this.setState({
//            rows :this.state.rows
//        }) 
//     }
       
      
//     render(){
//         return(
//             <div>
//                 <input type="text" id="input" value={this.state.inputValue} onChange={this.handleChange()}/>
//                 <input
//                 type="button"
//                 value="Alert the text input"
//                 onClick={this.handleClick()}
//                 />
                
//             </div>
        

//         )
//     };
// }
// export default List;